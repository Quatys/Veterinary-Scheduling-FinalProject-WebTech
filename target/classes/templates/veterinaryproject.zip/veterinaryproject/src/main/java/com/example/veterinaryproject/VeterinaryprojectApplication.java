package com.example.veterinaryproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeterinaryprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(VeterinaryprojectApplication.class, args);
    }

}
