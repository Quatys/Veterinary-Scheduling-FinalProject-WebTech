package com.example.veterinaryproject.controller;

import ch.qos.logback.core.model.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    @GetMapping("/")
    public String home(Model model) {
        // Add logic to display home page
        return "index";
    }

    // Dashboard page
    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        // Add logic to prepare the model for the dashboard page
        return "dashboard";
    }


    @GetMapping("/makeappointment")
    public String showMakeAppointmentForm() {
        // Add logic to display make appointment form
        return "makeappointment";
    }

    @GetMapping("/appointmentlist")
    public String showAppointmentList() {
        // Add logic to display appointment list
        return "appointmentlist";
    }

    @GetMapping("/calendar")
    public String showCalendar() {
        // Add logic to display calendar
        return "calendar";
    }


}
