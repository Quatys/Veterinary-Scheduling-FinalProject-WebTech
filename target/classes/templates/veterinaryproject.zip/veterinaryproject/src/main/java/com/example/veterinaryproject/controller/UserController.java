package com.example.veterinaryproject.controller;

import ch.qos.logback.core.model.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {


    // Registration
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(Model model) {
        return "redirect:/login";
    }

    // Login
    @GetMapping("/login")
    public String showLoginForm(Model model) {
        // Add logic to display login form
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(Model model) {
        // Add logic to authenticate the user
        // Redirect to dashboard after successful login
        return "redirect:/dashboard";
    }

}
